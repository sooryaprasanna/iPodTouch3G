# g1lbertJB
- This project is presented by the San Antonio Detective Unit (selfisht, PrimePlatypus, LukeZGD, and frog)
- g1lbertJB is a jailbreak tool for iOS 5.0 to 6.1.2.
- This supports all iOS devices that received the supported versions.
- Please join our [Discord server](https://discord.gg/kWmGBSUhyW) for updates and questions!
- For g1lbertCFW, go to the [g1lbertCFW repo](https://github.com/eatingurtoes/g1lbertCFW/).

# Platform support
- g1lbertJB supports macOS, Linux and Windows.
- On Windows, this makes use of bsdtar. Make sure that you are using Windows 10 1803 or newer.

# How to use
- Get the [latest release](https://github.com/g1lbertJB/g1lbertJB/releases/latest).
- Plug in your iOS device that you want to jailbreak in normal mode.

## Windows

- Open g1lbertJB by running `g1lbertJB.exe`


## macOS

- Open g1lbertJB by running `g1lbertJB.command`

## Linux

- Open Terminal, `cd` to the g1lbertJB directory, drag `gilbertjb` to the Terminal window, and press Enter/Return.

## Notes

- Ignore the "Error Code 1" and "Error Code 102" errors, this is normal and part of the jailbreaking process.
- For Linux users, select the correct architecture. This will be `x86_64` for most users.
- For Linux users, make sure that usbmuxd is installed, and run `sudo systemctl stop usbmuxd; sudo usbmuxd -pf` in another Terminal window before running g1lbertJB.

# Acknowledgements
- Thanks to everyone on the team for making this possible, and meeza for helping with testing
- Thanks to Merculous for the help and support on this project
- Thanks to whoever made unthredera1n, the base of this project
- Thanks to the evad3rs for the evasi0n untether used on iOS 6.0 to 6.1.2
